package com.gamingroom;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	long id;
	String name;
	
	// A list of all players
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	// Add player to list of players
	public Player addPlayer(String name) {
		Player player = null;
		
		for(Player current : players) {
			if(current.name.equalsIgnoreCase(name)) {
				return current;
			}
		}
		
		// If player does not exist, get next player ID
		GameService tempService = GameService.getInstance();
		
		player = new Player(tempService.getNextPlayerId(), name);
		
		players.add(player);
		
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
