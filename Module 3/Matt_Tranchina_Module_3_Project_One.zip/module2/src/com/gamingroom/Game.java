package com.gamingroom;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity{
	long id;
	String name;
	
	// List of all teams
	private static List<Team> teams = new ArrayList<Team>();
	
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Game() {
	}

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	// Add team to list of teams
	public Team addTeam(String name) {
	// a local game instance
		Team team = null;

		for (Team current : teams) {
			if(current.name.equalsIgnoreCase(name)) {
				return current;
			}
		}
		
		// If Team is not found, get next team ID
		GameService tempService = GameService.getInstance();
		
		team = new Team(tempService.getNextTeamId(), name);
		
		teams.add(team);
		
		return team;
		
		
	}

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
