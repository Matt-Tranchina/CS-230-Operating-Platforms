package com.gamingroom;
/**
 * Hold the common attributes and behaviors
 * Modifiers are protected so they can still be 
 * accesses by subclasses
 * @author tranc
 *
 */
public class Entity {
	
	protected long id;
	protected String name;
	
	// Default constructor
	protected Entity() {
		
	}
	// Overloaded method
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
		
	}
	
	// Return the ID
	public long getId() {
		return id;
	}
	
	// Return the Name
	public String getName() {
		return name;
	}
	
	
	

}
